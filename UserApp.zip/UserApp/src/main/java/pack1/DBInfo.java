package pack1;

public interface DBInfo {
	String driver = "oracle.jdbc.OracleDriver";
	String Dburl = "jdbc:oracle:thin:@localhost:1521:xe";
	String Dbun = "system";
	String dbpass = "RAMBABU" ;
}
